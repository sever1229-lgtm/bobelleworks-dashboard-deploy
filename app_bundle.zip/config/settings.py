from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()

DEFAULT_SPREADSHEET_ID = ""
EXPECTED_SHEETS = (
    "대시보드", "월별실적", "재고현황", "상품·SKU관리", "발주",
    "입고 및 재고 조정", "판매 및 반품", "운영비", "입출금",
)

RANGES = {
    "대시보드": "A1:Z30",
    "월별실적": "A5:L18",
    "재고현황": "A5:L105",
    "상품·SKU관리": "A5:N105",
    "발주": "A5:P105",
    "입고 및 재고 조정": "A5:L505",
    "판매 및 반품": "A5:U505",
    "운영비": "A5:F505",
    "입출금": "A5:G505",
}

DATE_COLUMNS = {
    "월별실적": ["월 시작"], "발주": ["발주일", "입고예정일"],
    "입고 및 재고 조정": ["일자"], "판매 및 반품": ["처리일"],
    "운영비": ["발생일"], "입출금": ["거래일"],
}

NUMERIC_COLUMNS = {
    "월별실적": ["매출", "매출원가", "판매 부대비", "공헌이익", "운영비", "관리손익", "실제 입금", "실제 출금", "순현금흐름", "월말 자금"],
    "재고현황": ["기초재고", "입고·조정", "판매·반품 차감", "현재고", "안전재고", "보충 필요수량", "참고 재고가액"],
    "상품·SKU관리": ["참고 원가 / 단위", "판매가 / 단위", "안전재고", "기초재고", "기초재고 단가"],
    "발주": ["발주수량", "예상 단가", "취소수량", "예상 발주액", "누적 입고수량", "미입고수량"],
    "입고 및 재고 조정": ["수량 증감", "단위원가", "배분 운송비", "입고 취득액"],
    "판매 및 반품": ["수량", "재입고 수량", "상품 순매출", "고객 배송비", "수수료", "택배비", "포장비", "당시 단위원가", "매출 합계", "매출원가", "공헌이익", "재고 차감수량"],
    "운영비": ["금액"], "입출금": ["입금", "출금"],
}

@dataclass(frozen=True)
class Settings:
    spreadsheet_id: str = os.getenv("GOOGLE_SPREADSHEET_ID", DEFAULT_SPREADSHEET_ID)
    timezone: str = os.getenv("APP_TIMEZONE", "Asia/Seoul")
    cache_ttl: int = int(os.getenv("CACHE_TTL_SECONDS", "120"))

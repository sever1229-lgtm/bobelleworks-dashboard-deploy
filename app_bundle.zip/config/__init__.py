"""Bobelle Works configuration."""


import pandas as pd
import plotly.express as px
import streamlit as st
from components.filters import period_filter, search_rows
from components.insights import build, render
from components.kpi_cards import metrics, num, pct, won
from components.tables import show
from runtime import context, title
from services.calculations import delayed_orders, filter_dates
from services.validation import validate_aggregates

d=context(); f=d.frames; title("Overview","매출, 수익성, 자금과 운영 상태를 한 화면에서 확인합니다.")
start,end,query=period_filter(f)
monthly=f["월별실적"]; m=monthly[monthly["월 시작"].between(start.to_period("M").start_time,end.to_period("M").start_time)].copy()
inv=f["재고현황"]; po=f["발주"]; sales=filter_dates(f["판매 및 반품"],"처리일",start,end)
tot=m[["매출","매출원가","판매 부대비","공헌이익","운영비","관리손익","순현금흐름"]].sum() if len(m) else pd.Series(dtype=float)
cash=float(m.iloc[-1]["월말 자금"]) if len(m) else 0; revenue=tot.get("매출",0); margin=tot.get("공헌이익",0)/revenue if revenue else 0
errors=sum((f[n].get(c,pd.Series(dtype=str)).astype(str)==v).sum() for n,c,v in [("판매 및 반품","입력 확인","입력 확인"),("입고 및 재고 조정","입력 확인","입력 확인"),("발주","상태","입력 확인"),("상품·SKU관리","중복 확인","중복 확인")])
metrics([("매출",won(revenue),"월별실적 값"),("공헌이익",won(tot.get("공헌이익",0)),"매출−매출원가−판매부대비"),("공헌이익률",pct(margin),"공헌이익÷매출"),("관리손익",won(tot.get("관리손익",0)),"공헌이익−운영비"),("현재자금",won(cash),"선택 기간의 마지막 월말 자금"),("재고자산",won(inv["참고 재고가액"].sum()),"재고현황 계산값")],3)
st.write(""); metrics([("현재고",num(inv["현재고"].sum()),None),("보충 필요 SKU",num((inv["상태"]=="보충 필요").sum()),None),("미입고수량",num(po["미입고수량"].sum()),None),("입력 오류",num(errors),None)],4)
st.subheader("월별 추이")
trend=m.melt(id_vars=["월 시작"],value_vars=["매출","공헌이익","관리손익"],var_name="항목",value_name="금액")
st.plotly_chart(px.line(trend,x="월 시작",y="금액",color="항목",markers=True,color_discrete_sequence=["#5468ff","#22a06b","#ff8a4c"]),use_container_width=True)
c1,c2=st.columns([1,1.7])
with c1:
    st.subheader("재고 상태")
    statuses=inv["상태"].replace("","정상").fillna("정상").value_counts().rename_axis("상태").reset_index(name="SKU")
    st.plotly_chart(px.pie(statuses,names="상태",values="SKU",hole=.62,color_discrete_sequence=["#30b77a","#ffb547","#e05252"]),use_container_width=True)
with c2:
    st.subheader("최근 판매·반품")
    recent=search_rows(sales,query).sort_values("처리일",ascending=False).head(8)
    show(recent[["처리일","주문번호","판매채널","상품명 (자동)","SKU","구분","재고 차감수량","매출 합계","공헌이익"]],currency=["매출 합계","공헌이익"],height=340)
st.subheader("주요 Alert & Insight")
today=pd.Timestamp.now(tz=d.settings.timezone).date()
record_start=f["대시보드"].iloc[0]["기록 시작일"]
history=monthly[(monthly["월 시작"]>=record_start.to_period("M").start_time)&(monthly["월 시작"]<=end.to_period("M").start_time)]
render(build(f,history,today))
with st.expander("Google Sheet 값 검증"):
    checks=validate_aggregates(f); selected=checks[checks["월"].between(start.to_period("M").start_time,end.to_period("M").start_time)]
    bad=selected[selected["상태"]!="일치"]
    st.success(f"선택 기간의 {len(selected)-len(bad):,}개 집계 항목이 일치합니다.") if bad.empty else st.error(f"{len(bad)}개 항목에서 차이가 발견되었습니다.")
    show(bad if len(bad) else selected,currency=["시트 값","웹 계산","차이"],height=300)

import plotly.express as px
import streamlit as st
from components.filters import multiselect,period_filter,search_rows
from components.tables import show
from runtime import context,title
from services.calculations import filter_dates,filter_text,product_summary

d=context(); f=d.frames; title("상품 분석","SKU별 매출 규모와 실제 공헌이익률을 함께 봅니다.")
start,end,query=period_filter(f); sales=filter_dates(f["판매 및 반품"],"처리일",start,end)
products=multiselect(sales,"상품명 (자동)","상품"); skus=multiselect(sales,"SKU","SKU")
sales=search_rows(filter_text(sales,{"상품명 (자동)":products,"SKU":skus}),query); p=product_summary(sales)
order=st.selectbox("정렬",["매출 높은 순","공헌이익 높은 순","공헌이익률 높은 순","공헌이익률 낮은 순"])
mapping={"매출 높은 순":("매출",False),"공헌이익 높은 순":("공헌이익",False),"공헌이익률 높은 순":("공헌이익률",False),"공헌이익률 낮은 순":("공헌이익률",True)}
if len(p): p=p.sort_values(mapping[order][0],ascending=mapping[order][1])
c1,c2=st.columns(2)
with c1: st.subheader("매출 TOP"); st.plotly_chart(px.bar(p.nlargest(10,"매출"),x="매출",y="SKU",orientation="h",color_discrete_sequence=["#5468ff"]),use_container_width=True)
with c2: st.subheader("공헌이익 TOP"); st.plotly_chart(px.bar(p.nlargest(10,"공헌이익"),x="공헌이익",y="SKU",orientation="h",color_discrete_sequence=["#22a06b"]),use_container_width=True)
st.subheader("매출 vs 공헌이익률")
st.plotly_chart(px.scatter(p,x="매출",y="공헌이익률",size="판매수량",color="상품명 (자동)",hover_name="SKU"),use_container_width=True)
st.subheader("저수익 상품")
show(p[p["매출"]>0].nsmallest(5,"공헌이익률")[["SKU","상품명 (자동)","매출","공헌이익","공헌이익률"]],currency=["매출","공헌이익"],percent=["공헌이익률"],height=260)
st.subheader("상품별 수익성"); show(p,currency=["매출","매출원가","판매부대비","공헌이익"],percent=["공헌이익률"])

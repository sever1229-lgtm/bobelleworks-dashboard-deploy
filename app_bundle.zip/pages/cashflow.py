import pandas as pd
import plotly.express as px
import streamlit as st
from components.filters import multiselect,period_filter,search_rows
from components.kpi_cards import metrics,won
from components.tables import show
from runtime import context,title
from services.calculations import filter_dates,filter_text

d=context(); f=d.frames; title("자금","실제 입출금과 운영상 손익을 분리해 확인합니다.")
start,end,query=period_filter(f); base=filter_dates(f["입출금"],"거래일",start,end)
types=multiselect(base,"구분","입출금 구분"); cash=search_rows(filter_text(base,{"구분":types}),query)
monthly=f["월별실적"]; m=monthly[monthly["월 시작"].between(start.to_period("M").start_time,end.to_period("M").start_time)].copy()
current=float(m.iloc[-1]["월말 자금"]) if len(m) else 0; opening=float(f["대시보드"].iloc[0]["시작 기초자금"])
metrics([("현재자금",won(current),"선택 기간 마지막 월말 자금"),("입금",won(cash["입금"].sum()),None),("출금",won(cash["출금"].sum()),None),("순현금흐름",won(cash["입금"].sum()-cash["출금"].sum()),"실제 현금 유입−유출"),("시작 기초자금",won(opening),None)],5)
st.subheader("월별 현금흐름과 월말 자금")
long=m.melt(id_vars=["월 시작"],value_vars=["실제 입금","실제 출금","순현금흐름","월말 자금"],var_name="항목",value_name="금액")
st.plotly_chart(px.line(long,x="월 시작",y="금액",color="항목",markers=True),use_container_width=True)
st.subheader("관리손익 vs 순현금흐름"); compare=m.melt(id_vars=["월 시작"],value_vars=["관리손익","순현금흐름"],var_name="항목",value_name="금액")
st.plotly_chart(px.bar(compare,x="월 시작",y="금액",color="항목",barmode="group"),use_container_width=True)
st.info("관리손익은 사업 운영상의 수익성이고, 순현금흐름은 실제 현금 유입에서 실제 현금 유출을 뺀 값입니다.")
st.subheader("입출금 상세"); show(cash.sort_values("거래일",ascending=False)[["거래일","계좌","구분","연결 주문 / 발주번호","내용","입금","출금"]],currency=["입금","출금"])
